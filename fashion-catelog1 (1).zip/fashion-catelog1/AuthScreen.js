import React, { useState } from 'react';
import { View, Text, TextInput, Button, Alert, StyleSheet, ImageBackground } from 'react-native';

const FIREBASE_URL = 'https://myproject-1cbf6-default-rtdb.firebaseio.com';

export default function AuthScreen({ navigation }) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const toggleMode = () => {
    setIsLogin(!isLogin);
    setEmail('');
    setPassword('');
  };

  const handleSubmit = async () => {
    const trimmedEmail = email.trim().toLowerCase();
    const trimmedPassword = password.trim();

    if (!trimmedEmail || !trimmedPassword) {
      Alert.alert('Error', 'Please fill in all fields.');
      return;
    }

    try {
      const response = await fetch(`${FIREBASE_URL}/users.json`);
      const data = await response.json();

      const users = data
        ? Object.entries(data).map(([key, val]) => ({
            id: key,
            email: val.email?.trim().toLowerCase(),
            password: val.password?.trim(),
          }))
        : [];

      if (isLogin) {
        const match = users.find(
          user => user.email === trimmedEmail && user.password === trimmedPassword
        );
        if (match) {
          Alert.alert('Success', 'Logged in successfully!');
          navigation.replace('FASHION CATALOG');
        } else {
          Alert.alert('Error', 'Invalid credentials.');
        }
      } else {
        const exists = users.some(user => user.email === trimmedEmail);
        if (exists) {
          Alert.alert('Error', 'User already exists.');
          return;
        }

        const saveResponse = await fetch(`${FIREBASE_URL}/users.json`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: trimmedEmail, password: trimmedPassword }),
        });

        if (!saveResponse.ok) throw new Error('Registration failed');

        Alert.alert('Success', 'Registered successfully!');
        navigation.replace('FASHION CATALOG');
      }
    } catch (error) {
      console.error('Firebase error:', error.message);
      Alert.alert('Error', 'Something went wrong.');
    }
  };

  return (
    <ImageBackground
      source={{ uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-5cGr9sV-eUef4QWvoF5dy_oD08S0Ryr4yA&s' }}
      style={styles.background}
      resizeMode="cover"
    >
      <View style={styles.overlay}>
        <Text style={styles.title}>{isLogin ? 'Login' : 'Register'} Form</Text>
        <TextInput
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
          style={styles.input}
          autoCapitalize="none"
          keyboardType="email-address"
        />
        <TextInput
          placeholder="Password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          style={styles.input}
        />
        <Button title={isLogin ? 'Login' : 'Register'} onPress={handleSubmit} />
        <Text style={styles.switchText} onPress={toggleMode}>
          {isLogin ? 'Don\'t have an account? Register' : 'Already registered? Login'}
        </Text>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
  },
  overlay: {
    backgroundColor: 'rgba(255,255,255,0.85)',
    margin: 20,
    padding: 20,
    borderRadius: 10,
  },
  container: {
    padding: 20,
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    padding: 10,
    marginVertical: 10,
    borderRadius: 5,
    backgroundColor: '#fff',
  },
  switchText: {
    color: 'blue',
    marginTop: 15,
    textAlign: 'center',
  },
});
