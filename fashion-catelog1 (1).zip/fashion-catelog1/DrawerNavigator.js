import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import HomeScreen from './HomeScreen';
import { View, Text } from 'react-native';

const Drawer = createDrawerNavigator();

// Reusable placeholder screen
const Screen = ({ route }) => (
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
    <Text style={{ fontSize: 24 }}>{route.name}</Text>
  </View>
);

export default function DrawerNavigator() {
  return (
    <Drawer.Navigator drawerPosition="right">
      <Drawer.Screen name="Home" component={HomeScreen} />
      <Drawer.Screen name="Themes" component={Screen} />
      <Drawer.Screen name="Occasions" component={Screen} />
      <Drawer.Screen name="Lookups" component={Screen} />
      <Drawer.Screen name="About Us" component={Screen} />
      <Drawer.Screen name="Contact Us" component={Screen} />
    </Drawer.Navigator>
  );
}
