// App.js
import React, { useState, useContext } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator, DrawerContentScrollView, DrawerItem } from '@react-navigation/drawer';
import { ThemeProvider, ThemeContext } from './Appmode'; // your theme context
import AuthScreen from './AuthScreen';

// Screens
import HomeScreen from './HomeScreen';
import CategoryScreen from './CategoryScreen';
import ThemesScreen from './ThemesScreen';
import LookupsScreen from './LookupsScreen';
import WelcomeScreen from './WelcomeScreen';
import OcassionsScreen from './OcassionsScreen';
import WishlistScreen from './WishlistScreen';


const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

function ContactUsScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Contact Us</Text>
      <Text>Email: FashionCatalog@gmail.com</Text>
      <Text>InstagramProfile:FashionCatalog</Text>
      <Text>Facebook:YourFashionCatalog</Text>
      <Text>Website:www.FashionCatalog.com.pk</Text>
      
      

    </View>
  );
}

function AboutUsScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>About Us</Text>
      <Text>a great opportunity to connect with your audience and build a brand identity what is best to outfit to wear at the different occasions 
      </Text>
    </View>
  );
}

function AppModesScreen() {
  const { isDark, toggleTheme } = useContext(ThemeContext);
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text style={{ fontSize: 20, marginBottom: 20 }}>
        Current Theme: {isDark ? 'Dark' : 'Light'}
      </Text>
      <TouchableOpacity onPress={toggleTheme} style={{ padding: 12, backgroundColor: '#888', borderRadius: 5 }}>
        <Text style={{ color: 'white' }}>Toggle Theme</Text>
      </TouchableOpacity>
    </View>
  );
}

function CustomDrawerContent(props) {
  const [settingsExpanded, setSettingsExpanded] = useState(false);
  return (
    <DrawerContentScrollView {...props}>
      <DrawerItem label="Home" onPress={() => props.navigation.navigate('Home')} />
      <DrawerItem label="Themes" onPress={() => props.navigation.navigate('Themes')} />
      <DrawerItem label="Occasions" onPress={() => props.navigation.navigate('Occasions')} />
      <DrawerItem label="Lookups" onPress={() => props.navigation.navigate('Lookups')} />
      <DrawerItem label="Favourites" onPress={() => props.navigation.navigate('Wishlist')} />

      <TouchableOpacity onPress={() => setSettingsExpanded(!settingsExpanded)} style={{ padding: 16 }}>
        <Text style={{ fontWeight: 'bold' }}>App Settings {settingsExpanded ? '▲' : '▼'}</Text>
      </TouchableOpacity>

      {settingsExpanded && (
        <View style={{ paddingLeft: 20 }}>
          <DrawerItem label="Contact Us" onPress={() => props.navigation.navigate('Contact Us')} />
          <DrawerItem label="About Us" onPress={() => props.navigation.navigate('About Us')} />
          <DrawerItem label="App Modes" onPress={() => props.navigation.navigate('App Modes')} />
        </View>
      )}
    </DrawerContentScrollView>
  );
}

function DrawerNavigator() {
  return (
    <Drawer.Navigator
      drawerPosition="right"
      drawerContent={(props) => <CustomDrawerContent {...props} />}
    >
      <Drawer.Screen name="Home" component={HomeScreen} />
      <Drawer.Screen name="Themes" component={ThemesScreen} />
      <Drawer.Screen name="Occasions" component={OcassionsScreen} />
      <Drawer.Screen name="Lookups" component={LookupsScreen} />
      <Drawer.Screen name="Favourites" component={WishlistScreen} />
      <Drawer.Screen name="Contact Us" component={ContactUsScreen} />
      <Drawer.Screen name="About Us" component={AboutUsScreen} />
      <Drawer.Screen name="App Modes" component={AppModesScreen} />
    </Drawer.Navigator>
  );
}

function MainApp() {
  const { theme } = useContext(ThemeContext);
  return (
    <NavigationContainer theme={theme}>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Welcome" component={WelcomeScreen} />
        <Stack.Screen name="Auth" component={AuthScreen} />
        <Stack.Screen name="FASHION CATALOG" component={DrawerNavigator} />
        <Stack.Screen name="Category" component={CategoryScreen} />
        <Stack.Screen name="Themes" component={ThemesScreen} />
        <Stack.Screen name="Lookups" component={LookupsScreen} />
        <Stack.Screen name="Occasions" component={OcassionsScreen} />
        <Stack.Screen name="Wishlist" component={WishlistScreen} />
        <Stack.Screen name="Contact Us" component={ContactUsScreen} />
        <Stack.Screen name="About Us" component={AboutUsScreen} />
        <Stack.Screen name="App Modes" component={AppModesScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default function AppWrapper() {
  return (
    <ThemeProvider>
      <MainApp />
    </ThemeProvider>
  );
}
