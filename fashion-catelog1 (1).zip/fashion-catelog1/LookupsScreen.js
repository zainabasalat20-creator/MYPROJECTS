import React from 'react';
import { View, Text, FlatList, Image, StyleSheet } from 'react-native';

const lookupData = [
  {
    id: '1',
    title: '',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTL6vnkGf5mit9NnM9XQy7KpmhB-S4mUFU-PbCBEpI0dmglUrIypyMbvIcFlmhJ12REwsM&usqp=CAU',
  },
  {
    id: '2',
    title: '',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSuSE4oVqvXzjDGHISTHM3r5j_l-9eF3pzZBG0v1SkTGlZYarDY5can4vfZeiGmc7k6qnw&usqp=CAU',
  },
  {
    id: '3',
    title: '',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTkBtydXbDdQd_0FFdJfSfGuyyh-Ycx9Cz1FS4XakLNd0CBoZHKDWNbVHTrB-K8Giro7Og&usqp=CAU',
  },
  {
    id: '4',
    title: '',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBcm9-pHqv-iw4exsrMXmUAsrcP2xyEUyNe5Hedh9-qvQTi8WO9ePZ-qKw9dQB0Mpt6eQ&usqp=CAU',
  },
  {
    id: '5',
    title: '',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSCTU2hTzj9m22Y1N14uXQTrlB_YEfau6D6i1Psd8Yud-jlUgZQ57fdsbDY0DyXICyXxjQ&usqp=CAU',
  },
 {
    id: '6',
    title: '',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRjA1gkB4jmJ_1ALjFAzBvcivUtiYaxUvEqgacrEd9FFZmPqEujeQcixvVmXFuhchEau_c&usqp=CAU',
  },
 {
    id: '7',
    title: '',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQWqjKe-Z-k3Dh_HOyA-2BnHHQQz30rEUIKsC8v4912U3ISO4kmwGoUiFc7S88DGWx6Jns&usqp=CAU',
  },
  {
    id: '8',
    title: '',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTlhC77YnUbtPawJzxf0-q-6QIvBylyUeNeme7wTQFrF7a7LNAqdVhN6RxH2k5ttoI0ntQ&usqp=CAU',
  },
   {
    id: '9',
    title: '',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRZvjGRu5BnvQ6ZJQoZFWVyKH66WI_j3_14Y6NO-7z0ojbATXaERTAKwNLPojrh7uMQs_0&usqp=CAU',

  },
  {
    id: '10',
    title: '',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQAR300Y8Vfr2jJYzACX5QqGtl4zSSqHb79qIjt6PeJWq5S-RNL_rtVAncwTTCGS5Z_RXA&usqp=CAU',
    
  },
  
  {
    id: '11',
    title: '',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQgS3rB1HxW5DpFpSZdo138N72YIBqVUDP_HTd5AP327gTGLVPTHQnSdXZOD0RVfIg8WsQ&usqp=CAU',
    
  },
  {
    id: '12',
    title: '',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT0I27Ddpqys9EPSD5VYZ1Sl5m5rGbQlBOhDMJJ1vD6-nYmnmQs_5wDG6KJA-xt93qEVcs&usqp=CAU',
    
  },
   {
    id: '13',
    title: '',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGr1p7WPEi4HOQEjFws7sbQ4vbWwKBWBzoLY5nmrQhSOg210QytJvp7TV-iLHcvXvdDCI&usqp=CAU',
    
  },
  {
    id: '14',
    title: '',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT3kpNugbOJ2_0FblbyYoxwLSzZRfrnhJAkWVfyYkcytwxyfllGC6fmyMvnT84WuL1F70E&usqp=CAU',
    
  },
  {
    id: '15',
    title: '',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQKKe8_9qBAdEvxtoXOZ5nq7sjYdxsJM_uO8A2r6KzqSTeEfNPJqPXyOXSCRKTjOi8qe8w&usqp=CAU',
    
  },
];

export default function LookupScreen() {
  const renderItem = ({ item }) => (
    <View style={styles.card}>
      <Image source={{ uri: item.image }} style={styles.image} />
      <Text style={styles.title}>{item.title}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Fashion Lookups</Text>
      <FlatList
        data={lookupData}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.list}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 16,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  list: {
    paddingHorizontal: 16,
  },
  card: {
    marginBottom: 20,
    backgroundColor: '#f8f8f8',
    borderRadius: 10,
    overflow: 'hidden',
    elevation: 3,
  },
  image: {
    height: 200,
    width: '100%',
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    padding: 12,
    textAlign: 'center',
  },
});
