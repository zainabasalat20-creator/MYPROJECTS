import React, { useContext } from 'react';
import { View, Button, StyleSheet, Text } from 'react-native';
import { Appmode} from './Appmode';

export default function AppSettingsScreen({ navigation }) {
  const { toggleTheme, isDark } = useContext(ThemeContext);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>App Settings</Text>
      <Button title={isDark ? "Switch to Light Theme" : "Switch to Dark Theme"} onPress={toggleTheme} />
      <Button title="About Us" onPress={() => navigation.navigate('About Us')} />
      <Button title="Contact Us" onPress={() => navigation.navigate('Contact Us')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: 'center' },
  title: { fontSize: 22, marginBottom: 20 },
});
