import React from 'react';
import { View, Text, Linking, StyleSheet, TouchableOpacity } from 'react-native';

export default function AboutUs() {
  const email = 'fashioncatalogapp@example.com';
  const instagram = 'https://www.instagram.com/fashioncatalogapp';
  const facebook = 'https://www.facebook.com/fashioncatalogapp';

  return (
    <View style={styles.container}>
      <Text style={styles.title}>About Us</Text>

      <Text style={styles.label}>Email:</Text>
      <Text style={styles.text}>{email}</Text>

      <Text style={styles.label}>Follow us on:</Text>

      <TouchableOpacity onPress={() => Linking.openURL(instagram)}>
        <Text style={styles.link}>Instagram</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => Linking.openURL(facebook)}>
        <Text style={styles.link}>Facebook</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 30,
    backgroundColor: '#f5f5f5',
    justifyContent: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 30,
  },
  label: {
    fontSize: 18,
    marginTop: 10,
    fontWeight: '600',
  },
  text: {
    fontSize: 16,
    marginBottom: 10,
  },
  link: {
    fontSize: 16,
    color: 'blue',
    marginTop: 5,
  },
});
